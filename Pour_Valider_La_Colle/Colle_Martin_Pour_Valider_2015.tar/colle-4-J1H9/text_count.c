/*
** text_count.c for t_c in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 18:55:17 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:49:40 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		text_count(int ac, char **av, int i, int cpt)
{
  t_opt		*opt;
  int		strs[2];

  opt = get_options(ac, av);
  if (opt->on_the_fly == 1)
    return (on_the_fly(opt));
  while (i != ac)
    {
      if (av[i][0] != '-')
	{
	  strs[cpt] = i;
	  ++cpt;
	}
      ++i;
    }
  if (cpt == 1)
    return (simple_text_count(av[strs[0]], opt, 0));
  else if (cpt == 2)
    return (double_text_count(av[strs[0]], av[strs[1]], opt, 0));
  else
    return (ERROR);
  return (SUCCESS);
}

t_opt		*get_options(int ac, char **av)
{
  t_opt		*opt;
  int		i;

  i = 0;
  if ((opt = malloc(sizeof(t_opt))) == NULL)
    return (NULL);
  opt = init_options(opt);
  while (i != ac)
    {
      if (av[i][0] == '-')
	{
	  if (av[i][1] == 't')
	    opt->t = 1;
	  else if (av[i][1] == 'r' && av[i][2] == '\0')
	    opt->r = 1;
	  else
	    {
	      opt = which_option_on(av[i], opt);
	      opt = which_option_off(av[i], opt);
	    }
	}
      ++i;
    }
  return (opt);
}

t_opt		*init_options(t_opt *opt)
{
  opt->t = 0;
  opt->r = 0;
  opt->reverse = 0;
  opt->on_the_fly = 0;
  return (opt);
}

t_opt		*which_option_on(char *str, t_opt *opt)
{
  if (my_strcmp("-reverse", str) == 0 ||
      my_strcmp("-reverse=on", str) == 0)
    opt->reverse = 1;
  else if (my_strcmp("-fullstat", str) == 0 ||
	   my_strcmp("-fullstat=on", str) == 0)
    my_putstr_error("Fullstat not implemented yet, sorry...\n");
  else if (my_strcmp("-on_the_fly", str) == 0 ||
	   my_strcmp("-on_the_fly=on", str) == 0)
    opt->on_the_fly = 1;
  return (opt);
}

t_opt		*which_option_off(char *str, t_opt *opt)
{
  if (my_strcmp("-reverse=off", str) == 0)
    opt->reverse = 0;
  else if (my_strcmp("-fullstat=off", str) == 0)
    my_putstr_error("Fullstat not implemented yet, sorry...\n");
  else if (my_strcmp("-on_the_fly=off", str) == 0)
    opt->on_the_fly = 0;
  return (opt);
}
