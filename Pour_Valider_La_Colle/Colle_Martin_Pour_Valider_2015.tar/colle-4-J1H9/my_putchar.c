/*
** my_putchar.c for my_putchar in /home/pellem_m/Rendu/Colles/colle-4-J1H9
**
** Made by Martin PELLEMOINE
** Login   <pellem_m@epitech.net>
**
** Started on  Wed May 20 19:00:30 2015 Martin PELLEMOINE
** Last update Wed May 20 22:31:16 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		my_putchar(char c)
{
  (void)write(1, &c, 1);
}
