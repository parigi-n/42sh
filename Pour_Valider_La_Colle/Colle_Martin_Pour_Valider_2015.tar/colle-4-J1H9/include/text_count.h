/*
** text_count.h for include tc in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 18:59:36 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:48:31 2015 Sylvain BIRUKOFF
*/

#ifndef TEXT_COUNT_H_
# define TEXT_COUNT_H_

# include <unistd.h>
# include <stdlib.h>

# define SUCCESS (0)
# define ERROR (-1)
# define BUFFSIZE (4096)

typedef struct	s_ltr
{
  unsigned char	letter;
  int		nb;
  struct s_ltr	*next;
  struct s_ltr	*prev;
}		t_ltr;

typedef struct	s_opt
{
  int		t;
  int		r;
  int		reverse;
  int		on_the_fly;
}		t_opt;

int		text_count(int, char **, int, int);

t_opt		*get_options(int, char **);
t_opt		*init_options(t_opt *);
t_opt		*which_option_on(char *, t_opt *);
t_opt		*which_option_off(char *, t_opt *);

int		simple_text_count(char *, t_opt *, int);
char		*swapping_str(char *, int);
t_ltr		*put_ltr_in_ll(t_ltr *, char, int);

int		double_text_count(char *, char *, t_opt *, int);
char		*swapping_str_double(char *, int, char);
t_ltr		*put_ltr_in_ll_double(t_ltr *, char, int);

t_ltr		*bubble(t_ltr *);
t_ltr		*bubble_swapping(t_ltr *);

int		on_the_fly(t_opt *);
int		otf_simple_or_double(t_opt *);
int		otf_simple_chosen(t_opt *);
int		otf_double_chosen(t_opt *);
char		*read_otf();

int		check_ltr(char);
void		show_ltr(t_ltr *, t_opt *);
void		show_simple_way(t_ltr *);
void		show_simple_way_part2(t_ltr *);
void		show_reversed(t_ltr *);
void		show_clean(t_ltr *);
void		show_clean_reversed(t_ltr *);

void		my_putchar(char);
void		my_putstr(char *);
void		my_putstr_error(char *);
void		my_put_nbr(int);
int		my_strcmp(char *, char *);

#endif /* !TEXT_COUNT_H_ */
