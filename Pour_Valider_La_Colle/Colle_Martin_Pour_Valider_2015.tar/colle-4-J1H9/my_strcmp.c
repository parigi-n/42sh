/*
** my_strcmp.c for my_strcmp in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 20:39:49 2015 Sylvain BIRUKOFF
** Last update Wed May 20 20:46:33 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		my_strcmp(char *s1, char *s2)
{
  int		i;

  i = 0;
  while (s1[i] != '\0' && s2[i] != '\0')
    {
      if (s1[i] != s2[i])
	return (ERROR);
      ++i;
    }
  if (s1[i] != '\0' || s2[i] != '\0')
    return (ERROR);
  return (SUCCESS);
}
