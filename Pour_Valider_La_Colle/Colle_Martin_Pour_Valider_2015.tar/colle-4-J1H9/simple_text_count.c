/*
** simple_text_count.c for simple tc in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 19:02:34 2015 Sylvain BIRUKOFF
** Last update Wed May 20 23:44:39 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		simple_text_count(char *str, t_opt *opt, int i)
{
  int		j;
  int		cpt;
  char		save;
  t_ltr		*list;

  list = NULL;
  while (str[i] != '\0')
    {
      save = str[i];
      j = -1;
      cpt = 0;
      while (str[++j] != '\0')
	{
	  if (str[j] == save)
	    {
	      str = swapping_str(str, j--);
	      ++cpt;
	    }
	}
      list = put_ltr_in_ll(list, save, cpt);
    }
  show_ltr(list, opt);
  return (SUCCESS);
}

char		*swapping_str(char *str, int j)
{
  int		i;

  i = 0;
  while (i != j)
    ++i;
  while (str[i] != '\0')
    {
      if (str[i + 1] != '\0')
	{
	  str[i] = str[i + 1];
	  ++i;
	}
      else
	str[i] = '\0';
    }
  return (str);
}

t_ltr		*put_ltr_in_ll(t_ltr *list, char save, int cpt)
{
  t_ltr		*elem;

  if ((elem = malloc(sizeof(t_ltr))) == NULL)
    return (NULL);
  elem->letter = save;
  elem->nb = cpt;
  elem->next = list;
  list = elem;
  if (elem->next != NULL)
    elem->next->prev = elem;
  return (list);
}
