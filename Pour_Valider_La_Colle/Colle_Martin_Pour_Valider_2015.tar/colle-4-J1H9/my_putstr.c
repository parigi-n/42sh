/*
** my_putstr.c for my_putstr in /home/pellem_m/Rendu/Colles/colle-4-J1H9
** 
** Made by Martin PELLEMOINE
** Login   <pellem_m@epitech.net>
** 
** Started on  Wed May 20 19:12:28 2015 Martin PELLEMOINE
** Last update Thu May 21 00:22:21 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		my_putstr(char *str)
{
  int		i;

  i = 0;
  while (str[i] != '\0')
    ++i;
  (void)write(1, str, i + 1);
}
