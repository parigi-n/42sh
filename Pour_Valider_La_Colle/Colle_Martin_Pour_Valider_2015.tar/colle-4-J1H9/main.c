/*
** main.c for main in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 18:55:14 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:39:34 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		main(int ac, char **av)
{
  if (ac <= 1)
    {
      my_putstr("\033[1;31m");
      my_putstr_error("You need something to work with, duh\n");
      my_putstr("\033[0m");
      return (ERROR);
    }
  text_count(ac, av, 1, 0);
  return (SUCCESS);
}
