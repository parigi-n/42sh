/*
** show_ltr.c for show in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 19:41:39 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:42:15 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		show_ltr(t_ltr *list, t_opt *opt)
{
  my_putstr("\033[1;32mResults :\n\033[0m");
  if (opt->t == 1)
    list = bubble(list);
  if (opt->r == 0 && opt->reverse == 0)
    show_simple_way(list);
  else if (opt->reverse == 1 && opt->r == 0)
    show_reversed(list);
  else if (opt->r == 1 && opt->reverse == 0)
    show_clean(list);
  else if (opt->r == 1 && opt->reverse == 1)
    show_clean_reversed(list);
  my_putstr("\033[1;35mYay, have a nice day!\n\033[0m");
}

void		show_simple_way(t_ltr *list)
{
  t_ltr		*tmp;

  tmp = list;
  if (list != NULL)
    {
      while (list->next != NULL)
	list = list->next;
      while (list != tmp)
	{
	  if (check_ltr(list->letter) == SUCCESS)
	    my_putchar((unsigned char)list->letter);
	  my_putchar(':');
	  my_put_nbr(list->nb);
	  my_putchar('\n');
	  list = list->prev;
	}
      show_simple_way_part2(list);
    }
}

void		show_simple_way_part2(t_ltr *list)
{
  if(check_ltr(list->letter) == SUCCESS)
    my_putchar((unsigned char)list->letter);
  my_putchar(':');
  my_put_nbr(list->nb);
  my_putchar('\n');
}

void		show_reversed(t_ltr *list)
{
  while (list != NULL)
    {
      if (check_ltr(list->letter) == SUCCESS)
	my_putchar((unsigned char)list->letter);
      my_putchar(':');
      my_put_nbr(list->nb);
      my_putchar('\n');
      list = list->next;
    }
}
