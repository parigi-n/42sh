/*
** check_ltr.c for check_ltr in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 22:14:10 2015 Sylvain BIRUKOFF
** Last update Wed May 20 23:46:17 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		check_ltr(char ltr)
{
  if ((ltr > '\a' && ltr < '\r') || ltr == ' ')
    {
      if (ltr == '\a')
        my_putstr("\\a");
      if (ltr == ' ')
        my_putstr("space");
      if (ltr == '\t')
        my_putstr("\\t");
      if (ltr == '\n')
        my_putstr("\\n");
      if (ltr == '\v')
        my_putstr("\\v");
      if (ltr == '\f')
        my_putstr("\\f");
      if (ltr == '\r')
        my_putstr("\\r");
      return (ERROR);
    }
  return (SUCCESS);
}
