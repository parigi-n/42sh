/*
** my_put_nbr.c for my_put_nbr in /home/pellem_m/Rendu/Colles/colle-4-J1H9
** 
** Made by Martin PELLEMOINE
** Login   <pellem_m@epitech.net>
** 
** Started on  Wed May 20 18:59:11 2015 Martin PELLEMOINE
** Last update Wed May 20 19:34:33 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		my_put_nbr(int nb)
{
  if (nb >= 10)
    {
      my_put_nbr(nb / 10);
      my_putchar((nb % 10) + 48);
    }
  else
    my_putchar(nb + 48);
}
