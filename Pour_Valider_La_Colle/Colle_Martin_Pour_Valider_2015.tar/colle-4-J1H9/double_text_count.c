/*
** double_text_count.c for double tc in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 19:39:19 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:06:38 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		double_text_count(char *str1, char *str2, t_opt *opt, int i)
{
  int		j;
  int		cpt;
  char		save;
  t_ltr		*list;

  list = NULL;
  while (str2[i] != '\0')
    {
      save = str2[i];
      j = 0;
      cpt = 0;
      while (str1[j] != '\0')
	{
	  if (save == str1[j])
	    ++cpt;
	  ++j;
	}
      str2 = swapping_str_double(str2, 0, save);
      if (cpt != 0)
	list = put_ltr_in_ll(list, save, cpt);
    }
  show_ltr(list, opt);
  return (SUCCESS);
}

char		*swapping_str_double(char *str, int i, char save)
{
  int		j;

  while (str[i] != '\0')
    {
      if (str[i] == save)
	{
	  j = i;
	  while (str[j] != '\0')
	    {
	      if (str[j + 1] != '\0')
		{
		  str[j] = str[j + 1];
		  ++j;
		}
	      else
		str[j] = '\0';
	    }
	}
      if (str[i] != save)
	++i;
    }
  return (str);
}

t_ltr		*put_ltr_in_ll_double(t_ltr *list, char save, int cpt)
{
  t_ltr		*elem;

  if ((elem = malloc(sizeof(t_ltr))) == NULL)
    return (NULL);
  elem->letter = save;
  elem->nb = cpt;
  elem->next = list;
  list = elem;
  if (elem->next != NULL)
    elem->next->prev = elem;
  return (list);
}
