/*
** show_ltr2.c for show ltr 2 in /home/biruko_s/tek1/colle-4-J1H9
** 
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
** 
** Started on  Wed May 20 22:16:54 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:17:23 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		show_clean(t_ltr *list)
{
  int		save_nb;

  list = bubble(list);
  while (list->next != NULL)
    list = list->next;
  while (list != NULL)
    {
      save_nb = list->nb;
      my_put_nbr(list->nb);
      my_putchar(':');
      while (list != NULL && save_nb == list->nb)
	{
	  if (check_ltr(list->letter) == SUCCESS)
	    my_putchar(list->letter);
	  list = list->prev;
	  if (list != NULL && list->nb == save_nb)
	    my_putstr(",");
	}
      my_putchar('\n');
    }
}

void		show_clean_reversed(t_ltr *list)
{
  int		save_nb;

  list = bubble(list);
  while (list != NULL)
    {
      save_nb = list->nb;
      my_put_nbr(list->nb);
      my_putchar(':');
      while (list != NULL && save_nb == list->nb)
	{
	  if (check_ltr(list->letter) == SUCCESS)
	    my_putchar(list->letter);
	  list = list->next;
	  if (list != NULL && list->nb == save_nb)
	    my_putstr(",");
	}
      my_putchar('\n');
    }
}
