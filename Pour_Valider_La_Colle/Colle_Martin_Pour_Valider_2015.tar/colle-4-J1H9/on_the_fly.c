/*
** on_the_fly.c for on the fly in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 21:34:04 2015 Sylvain BIRUKOFF
** Last update Wed May 20 22:44:14 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

int		on_the_fly(t_opt *opt)
{
  otf_simple_or_double(opt);
  return (SUCCESS);
}

int		otf_simple_or_double(t_opt *opt)
{
  int		len;
  char		*buff;


  if ((buff = malloc(sizeof(char) * BUFFSIZE)) == NULL)
    return (ERROR);
  my_putstr("\033[1;31mWanna try it with 1 or 2 strings?\n\033[0m>> ");
  if ((len = read(0, buff, BUFFSIZE)) <= 0)
    return (ERROR);
  buff[len - 1] = '\0';
  if (my_strcmp("1", buff) == 0)
    otf_simple_chosen(opt);
  else if (my_strcmp("2", buff) == 0)
    otf_double_chosen(opt);
  else
    {
      my_putstr_error("\033[1;31mChoose 1 or 2 please ");
      my_putstr_error("\033[1;36msnif... T_T\033[0m\n");
    }
  free(buff);
  return (SUCCESS);
}

int		otf_simple_chosen(t_opt *opt)
{
  int		i;
  int		len;
  char		*buff;

  i = 0;
  while (i != 1)
    {
      my_putstr("\033[1;32mEnter the string \033[0m>> ");
      if ((buff = malloc(sizeof(char) * BUFFSIZE)) == NULL)
	return (ERROR);
      if ((len = read(0, buff, BUFFSIZE)) <= 0)
	return (ERROR);
      buff[len - 1] = '\0';
      ++i;
    }
  simple_text_count(buff, opt, 0);
  return (SUCCESS);
}

int		otf_double_chosen(t_opt *opt)
{
  int		i;
  char		*buff1;
  char		*buff2;

  i = 0;
  while (i != 2)
    {
      if (i == 0)
	{
	  my_putstr("\033[1;36mEnter the first string \033[0m>> ");
	  buff1 = read_otf();
	}
      else if (i == 1)
	{
	  my_putstr("\033[1;36mEnter the second string \033[0m>> ");
	  buff2 = read_otf();
	}
      ++i;
    }
  double_text_count(buff1, buff2, opt, 0);
  return (SUCCESS);
}

char		*read_otf()
{
  char		*buff;
  int		len;

  if ((buff = malloc(sizeof(char) * BUFFSIZE)) == NULL)
    return (NULL);
  if ((len = read(0, buff, BUFFSIZE)) <= 0)
    return (NULL);
  buff[len - 1] = '\0';
  return (buff);
}
