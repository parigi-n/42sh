/*
** my_putstr_error.c for my_putstr_error in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 20:26:31 2015 Sylvain BIRUKOFF
** Last update Wed May 20 20:27:13 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

void		my_putstr_error(char *str)
{
  int		i;

  i = 0;
  while (str[i] != '\0')
    ++i;
  (void)write(2, str, i + 1);
}
