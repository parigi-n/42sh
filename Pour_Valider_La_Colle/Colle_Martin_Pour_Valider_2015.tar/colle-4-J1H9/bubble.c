/*
** bubble.c for bubble in /home/biruko_s/tek1/colle-4-J1H9
**
** Made by Sylvain BIRUKOFF
** Login   <biruko_s@epitech.net>
**
** Started on  Wed May 20 20:09:05 2015 Sylvain BIRUKOFF
** Last update Wed May 20 20:24:39 2015 Sylvain BIRUKOFF
*/

#include "text_count.h"

t_ltr		*bubble(t_ltr *list)
{
  t_ltr		*start;
  int		done;

  start = list;
  done = 0;
  while (done == 0)
    {
      list = start;
      while (list != NULL)
	{
	  if (list->next != NULL && list->next->nb < list->nb)
	    {
	      list = bubble_swapping(list);
	      ++done;
	    }
	  list = list->next;
	}
      if (done != 0)
	done = 0;
      else
	done = 1;
    }
  return (start);
}

t_ltr		*bubble_swapping(t_ltr *list)
{
  int		save_nb;
  char		save_letter;

  save_letter = list->letter;
  save_nb = list->nb;
  list->letter = list->next->letter;
  list->nb = list->next->nb;
  list->next->letter = save_letter;
  list->next->nb = save_nb;
  return (list);
}
